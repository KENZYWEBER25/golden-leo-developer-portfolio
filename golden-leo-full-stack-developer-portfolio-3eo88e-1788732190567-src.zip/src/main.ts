import './styles.css';
const menu = document.querySelector<HTMLButtonElement>('.menu');
const nav = document.querySelector<HTMLElement>('nav');
menu?.addEventListener('click', () => { if (nav) nav.style.display = nav.style.display === 'flex' ? '' : 'flex'; });